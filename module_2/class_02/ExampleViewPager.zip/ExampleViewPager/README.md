# Ejemplo de ViewPager en Android

Requiere la instalación de la **librería de soporte de Android versión 3 o superior** *(Android Support Library)*.

Requiere la instalación de la **librería ViewPagerIndicator** que puedes descargar [aquí](http://viewpagerindicator.com/ "ViewPagerIndicator").

Para más información visita mi blog http://wp.me/p3fGeG-55