package com.example.examplefragmenti;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class Home2Activity extends FragmentActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity__home2);
	}

}
