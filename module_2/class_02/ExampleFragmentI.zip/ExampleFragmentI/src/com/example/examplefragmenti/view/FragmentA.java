package com.example.examplefragmenti.view;

import com.example.examplefragmenti.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

public class FragmentA extends Fragment {
	
	private Button btnA;
	private View viewA;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Log.v("CONSOLE", "1. FragmentA onCreate");
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Log.v("CONSOLE", "2. onCreateView");
		View view = inflater.inflate(R.layout.fragment_a, container);
		//return super.onCreateView(inflater, container, savedInstanceState);
		return view;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Log.v("CONSOLE", "3. onActivityCreated");
		super.onActivityCreated(savedInstanceState);
		btnA = (Button)getView().findViewById(R.id.btnA);
		viewA = getView().findViewById(R.id.bgFragmentA);
		btnA.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				viewA.setBackgroundColor(getResources().getColor(R.color.color_r));
			}
		});
		
	}

}
