package com.example.templateappandroid;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockActivity;

import android.os.Bundle;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class HomeActivity extends SherlockActivity {

	ActionBar bar;
	AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		bar = getSupportActionBar();
		
		View customView = LayoutInflater.from(this).inflate(R.layout.layout_actionbar, null);
		//customizar actionbar
		bar.setCustomView(customView);
		bar.setDisplayShowCustomEnabled(true);
		bar.setDisplayShowHomeEnabled(false);
		
		//events
		Button btnBack =(Button)bar.getCustomView().findViewById(R.id.btnBack);
		Button btnNext =(Button)bar.getCustomView().findViewById(R.id.btnNext);
		ImageView imgLogo =(ImageView)bar.getCustomView().findViewById(R.id.imgLogo);
		
		btnBack.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				exitApp("Back");
			}
		});
		
		btnNext.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				exitApp("Next");
			}
		});
		
		
	}
	protected void exitApp(String msg) {
		// TODO Auto-generated method stub
		Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
		dialog = new AlertDialog.Builder(this);
		dialog.setTitle("Alerta !");
		dialog.setMessage("Deseas cerrar la aplicaci�n ?");
		dialog.setCancelable(true);
		
		//events
		dialog.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				aceptar();
			}
		});
		dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				cancelar();
			}
		});
		
		dialog.show();
		
		
		
	}
	protected void cancelar() {
		// TODO Auto-generated method stub
		
	}
	protected void aceptar() {
		// TODO Auto-generated method stub
		
		this.finish();
	}



}
